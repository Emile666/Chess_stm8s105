/*	SIMPLIFIED PRINT
 *	Copyright (c) 2002 by COSMIC Software
 */
#include <string.h>

static char *sptr;	/* sprintf pointer */

/*	output text
 */
static void _putbuf(char *s, char n)
	{
	char *p;

	if (sptr)
		{
		do
			*sptr++ = *s++;
		while (--n);
		*sptr = '\0';
		}
	else
		{
		do
			putchar(*s++);
		while (--n);
		}
	}

/*	convert short integer
 */
static int _itob(char *is, int val, signed char ibase)
	{
	char *s, *p;
	struct {
		unsigned int uval;
		unsigned char base;
		unsigned char rem;
		} v;
	char c;
	static const char digstr[16] = {"0123456789abcdef"};

	s = is;
	v.base = (ibase < 0) ? -ibase : ibase;
	if (ibase < 0 && val < 0)
		{
		val = -val;
		*s++ = '-';
		}
	v.uval = val;
	p = s;
	do	{
		_udiv(&v);
		*s++ = digstr[v.rem];
		} while (v.uval);
	v.uval = s - is;
	while (p < --s)
		{
		c = *p;
		*p++ = *s;
		*s = c;
		}
	return (v.uval);
	}

/*	internal print routine
 */
int _print(char **ps, char *f, int *pp)
	{
	char *s, *q, type, buf[8];
	int n, nchars;

	sptr = (ps) ? *ps : 0;
	for (nchars = 0; ; f = q + 1)
		{
		for (q = f; *q && *q != '%'; ++q)
			;
		if (n = q - f)
			{
			_putbuf(f, n);
			nchars += n;
			}
		if (!*q++)
			return (nchars);
		type = 1;
		s = buf;
		switch (*q)
			{
		case 'c':
			*s = *pp;
			n = 1;
			break;
		case 'o':
			type = 8; goto convint;
		case 'x':
			type = 16; goto convint;
		case 'u':
			type = 10; goto convint;
		case 'd':
			type = -10;
		convint:
			n = _itob(s, *pp, type);
			break;
		case 's':
			s = (char *)*pp;
			n = strlen(s);
			break;
		default:
			s = q;
			n = 1;
			type = 0;
			}
		if (n)
			{
			_putbuf(s, n);
			nchars += n;
			}
		if (type)
			++pp;
		}
	}
