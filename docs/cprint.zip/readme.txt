	
This folder contains a simplified version of the print formatting routines (cprint.o) used by the standard C sprintf and printf functions.  This version is useful when sprintf and/or printf are used with char and int arguments. It does not support long, float or double arguments.  This simplified version produces a significantly smaller and faster version of the formatting routines.  

According to ANSI and ISO standards, both printf and sprintf must support many different types, conversions and formatting options which together results in a substantial amount of code for an embedded application. The Cosmic integer only library helps reduce the size while still supporting all integral data types and format specifiers including char, int, short and longs data types.  Long data types are usually 32 bit objects that require additional code when used on an 8 or 16 bit processor.  Cosmic also offers a reduced version of sprintf and printf by removing support for longs and the associated conversion and format conversions.  You can significantly reduce the code size of both printf and sprintf by replacing the standard "cprint.o" module in the integer library with the simplified version in this folder.  

This version will support chars, integers, shorts and strings and format modifiers %c, %o, %d, %x, %X, %u and %s. It does not support long, floats or double and their associated format modifiers.  To use this simplified formatting routine follow the instructions below:

1) Add cprint.c to your application and build with the same memory model options (if any) as your application.

2) Add cprint.o to your link command file just before the integer library  e.g.

+seg .text -b0xc000
+seg .data -b0x100
main.o
... 

cprint.o
c:\cosmic\cx__\lib\libi.hXX
c:\cosmic\cx__\lib\libm.hXX

